# 20230727 -  错误修改,消息改进

- 🔧解决使用 Matrix 条件判断的一些遗留问题
-  ➕新增 Matrix Wiki
- ➕新增 Matrix 警报悬浮消息
- ➕新增 Matrix  警报可以点击执行踢出指令
- ❌未尝试拯救 Spartan AntiCheat


# 20230713 - 正式编写更新日志

- 🔧修复 Matrix 警报消息的一处异常
- ⬇️降低 Matrix Move 增长vl速度
- ⬇️降低 Matrix Scaffold 违规后的增长vl值
- 😀宽松 Matrix Elytra 违规踢出阈值
- 🤯关闭 Matrix Elytra 检测拉回 
- ⚙️修改 Vulcan 踢出信息为 AAC 子模块（未100%完成）
- ⚙️修改 Vulcan 违规后随机旋转玩家头部的最低阈值
- ⚙️修改 GrimAC 踢出信息
- 😀宽松 GrimAC Reach 检测
- ❌未尝试拯救 Spartan AntiCheat
